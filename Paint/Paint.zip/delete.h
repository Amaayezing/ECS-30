//
// Created by maaye on 12/13/2017.
//

#ifndef PAINT_DELETE_H
#define PAINT_DELETE_H
#include "inputStruct.h"
void deleteRow(plottingPoints user, char*** board, int* numRows, int* numCols);
void deleteCol(plottingPoints user, char** board, int* numRows, int* numCols);
#endif //PAINT_DELETE_H
