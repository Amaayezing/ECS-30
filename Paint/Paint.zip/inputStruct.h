//
// Created by maaye on 12/13/2017.
//

#ifndef PAINT_INPUTSTRUCT_H
#define PAINT_INPUTSTRUCT_H

typedef struct plottingPoints_struct {
  int xOne;
  int yOne;
  int xTwo;
  int yTwo;
  int xy;
  char user;
} plottingPoints;

#endif //PAINT_INPUTSTRUCT_H