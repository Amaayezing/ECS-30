//
// Created by maaye on 12/13/2017.
//

#ifndef PAINT_ADD_H
#define PAINT_ADD_H
#include "inputStruct.h"
void addCol (plottingPoints user, char** board, int* numRows, int* numCols);
void addRow (plottingPoints user, char*** board, int* numRows, int* numCols);
#endif //PAINT_ADD_H
