//
// Created by maaye on 12/14/2017.
//

#ifndef PAINT_DRAWLINES_H
#define PAINT_DRAWLINES_H
void horizontal(plottingPoints user, char** board, int* numRows, int* numCols);
void vertical(plottingPoints user, char** board, int* numRows, int* numCols);
void leftDiagonal(plottingPoints user, char** board, int* numRows, int* numCols);
void rightDiagonal(plottingPoints user, char** board, int* numRows, int* numCols);
#endif //PAINT_DRAWLINES_H