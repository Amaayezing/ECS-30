//  Maayez Imam 10/30/2017
//  Anagram program

#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>
#include <string.h>

void anagram();
int checkAnagram(char [], char []);


void anagram() {
  char firstWord[20];
  char secondWord[20];
  int check;

  printf("Please enter the first word: ");
  scanf(" %s", firstWord);

  printf("Please enter the second word: ");
  scanf(" %s", secondWord);

  check = checkAnagram(firstWord, secondWord);

  if (check == 1) {
    printf("%s is an anagram of %s\n", firstWord, secondWord);
  }
  else {
    printf("%s is NOT an anagram of %s\n", firstWord, secondWord);
  }
}


int checkAnagram(char firstWord[], char secondWord[]) {
  char lowerFirstWord[20];
  char lowerSecondWord[20];
  int arrayOne[26] = {0};
  int arrayTwo[26] = {0};
  int i = 0;
  int j = 0;

  strcpy(lowerFirstWord, firstWord);
  strcpy(lowerSecondWord, secondWord);

  for(j = 0; lowerFirstWord[j]!= '\0'; j++) {
    lowerFirstWord[j] = tolower(lowerFirstWord[j]);
  }

  for(j = 0; lowerSecondWord[j]!= '\0'; j++) {
    lowerSecondWord[j] = tolower(lowerSecondWord[j]);
  }

  while (lowerFirstWord[i] != '\0') {
    arrayOne[lowerFirstWord[i]-'a']++;
    i++;
  }

  i = 0;

  while (lowerSecondWord[i] != '\0') {
    arrayTwo[lowerSecondWord[i]-'a']++;
    i++;
  }
  for (i = 0; i < 26; i++) {
    if (arrayOne[i] != arrayTwo[i])
      return 0;
  }
  return 1;
}

int main() {

  anagram();

  return 0;
}
