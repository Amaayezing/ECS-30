#ifndef CONNECTLINE_H
#define CONNECTLINE_H
void vertical(plottingPoints user, char **board, int *rowNum, int *colNum);
void horizontal(plottingPoints user, char **board, int *rowNum, int *colNum);
void rightDiagonal(plottingPoints user, char **board, int *rowNum, int *colNum);
void leftDiagonal(plottingPoints user, char **board, int *rowNum, int *colNum);
#endif /* connectLine_c */
