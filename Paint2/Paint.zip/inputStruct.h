#ifndef USERINPUTSTRUCT_H
#define USERINPUTSTRUCT_H
typedef struct plottingPoints_struct {
      int xy;
      int xOne;
      int xTwo;
      int yOne;
      int yTwo;
  } plottingPoints;
#endif /* userInputStruct_h */