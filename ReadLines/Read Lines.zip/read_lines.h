//
// Created by Maayez Imam on 11/29/2017.
//

#ifndef read_lines_h
#define read_lines_h

void read_lines(FILE* file, char*** lines, int* line_num);

#endif /* read_lines_h */
